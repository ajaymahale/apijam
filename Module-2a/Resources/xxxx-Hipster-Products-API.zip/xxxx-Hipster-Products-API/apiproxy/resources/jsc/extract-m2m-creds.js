const m2mCreds = context.getVariable('request.header.Authorization').split(" ")[1];
print(m2mCreds);
context.setVariable("m2m-creds", m2mCreds);